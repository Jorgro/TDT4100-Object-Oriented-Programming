package _4721;

public interface FinancialInstitution {
    public int getTotalAmount();
    public boolean isSafe();
    }